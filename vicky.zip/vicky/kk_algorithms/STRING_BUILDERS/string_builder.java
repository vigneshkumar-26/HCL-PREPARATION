package com.vicky.kk_algorithms.STRING_BUILDERS;

public class string_builder {
    public static void main(String[] args) {
        System.out.println("this is program of doing the use of string builder");
        StringBuilder sb = new StringBuilder();
        for(int i =0;i<26;i++){
            char ch = (char)('a'+i);
            sb.append(ch);
        }
        System.out.println(sb.toString());
        sb.reverse();
        System.out.println(sb.toString());
        sb.deleteCharAt(0);
        System.out.println(sb.toString());
    }
}
