package com.vicky.kk_algorithms.STRING_BUILDERS;

public class prettyprinting {
    public static void main(String[]args){
        System.out.println("this is the pretty printing in java");
        float a = 3.143f;
        System.out.printf("this is the decimal number of pi : %.2f",a);
        System.out.println();
        System.out.printf("this is the pi value:%.2f",Math.PI);
        System.out.println();
        System.out.printf("hi my name is %s and %s","vignesh kumar","cool");
    }
}
