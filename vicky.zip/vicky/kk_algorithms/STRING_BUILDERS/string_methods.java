package com.vicky.kk_algorithms.STRING_BUILDERS;

import java.util.Arrays;

public class string_methods {
    public static void main(String[] args) {
        System.out.println("this is the program of implementing string methods");
        String name = "VIGNESH KUMAR";
        System.out.println(Arrays.toString(name.toCharArray()));
        System.out.println(name.toLowerCase());
        System.out.println(name.indexOf('V'));
        System.out.println(" vignesh kumar v ".strip());
        System.out.println(Arrays.toString(name.split(" ")));
    }
}
