package com.vicky.KK_OOPS.INHERITANCE;

public class main {
    public static void main(String[] args) {
        System.out.println("this is the inheritane of program");
        box inherit = new box();
        box inherit2 = new box(inherit);
        System.out.println(inherit.l + " " + inherit.h + " " + inherit.w);
        box_weight weightbox = new box_weight(1,2,3,4);
        System.out.println(weightbox.weight+" "+inherit.l+" "+inherit.h);


    }
}