package com.vicky.KK_OOPS.INHERITANCE;

public class box_weight extends box {
    double weight;

    box_weight(){
        this.weight = -2;
    }

    box_weight(double l,double h,double w,double weight){
        super(l,h,w);
        this.weight=weight;
    }
}
