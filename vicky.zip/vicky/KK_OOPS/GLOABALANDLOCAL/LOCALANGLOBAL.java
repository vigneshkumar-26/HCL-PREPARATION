package com.vicky.KK_OOPS.GLOABALANDLOCAL;

    public class LOCALANGLOBAL {
        // Global variable (Instance variable)
        int globalVar = 10;

        public void methodOne() {
            // Local variable
            int localVar = 5;

            System.out.println("Local variable: " + localVar);
            System.out.println("Global variable from methodOne: " + globalVar);
        }

        public void methodTwo() {
            // Local variable
            int localVar = 20;

            System.out.println("Local variable: " + localVar);
            System.out.println("Global variable from methodTwo: " + globalVar);
        }

        public static void main(String[] args) {
            LOCALANGLOBAL obj = new LOCALANGLOBAL();

            // Calling methods to demonstrate the use of local and global variables
            obj.methodOne();
            obj.methodTwo();
        }
    }

