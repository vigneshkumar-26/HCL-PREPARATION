package com.vicky.KK_OOPS.CLASSANDOBJ;

class appform{
    String name;
    int rollno;

    public void display(){
        System.out.println(name);
        System.out.println(rollno);
    }

    public void setvalues(String str,int nums){
        name = str;
        rollno = nums;
    }

    public void setvalues1(String str,int nums){
        name = str;
        rollno = nums;
    }
}

public class oops_classandobj {
    public static void main(String[]args){
        System.out.println("this it program of class and object in oops");

        appform vs = new appform();
        vs.name="vicky";
        vs.rollno=69;
        vs.display();

        appform sv = new appform();
        sv.name = "sharon papa";
        sv.rollno = 96;
        sv.display();

        vs.setvalues("sharon",143);
        vs.display();

        vs.setvalues1("joyce",13);
        vs.display();
    }
}
