package com.vicky.KK_OOPS.CLASSANDOBJ;

public class kk_classandobj {
    public static void main(String[] args) {
        System.out.println("this is the program of the kushal k class , obj, keyword,constructor");
        student vs = new student();
//        vs.student();
        System.out.println(vs.name);
        System.out.println(vs.rollno);
        System.out.println(vs.marks);
    }
}

class student{
    String name;
    int rollno;
    float marks;

    student(){
        this.name = "sharon";
        this.rollno = 69;
        this.marks =99.9f;
    }


//    void student(){
//        System.out.println(this.name);
//        System.out.println(this.marks);
//        System.out.println(this.rollno);
//    }
}