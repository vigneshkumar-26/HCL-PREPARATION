package com.vicky;
import java.util.Arrays;


public class demo {
    public static int maxProfit(int[] prices) {
        if (prices == null || prices.length < 2) {
            return 0; // Not enough data to make a profit
        }

        int minPrice = Integer.MAX_VALUE; // Initialize the minimum price as a very large value
        int maxProfit = 0; // Initialize maximum profit as 0

        // Iterate through the array
        for (int price : prices) {
            // Update the minimum price
            if (price < minPrice) {
                minPrice = price;
            } else {
                // Calculate profit and update maxProfit if higher
                int profit = price - minPrice;
                maxProfit = Math.max(maxProfit, profit);
            }
        }
        return minPrice;
    }
}

