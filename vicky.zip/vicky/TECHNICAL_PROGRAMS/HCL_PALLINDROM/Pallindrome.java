package com.vicky.TECHNICAL_PROGRAMS.HCL_PALLINDROM;

import java.util.Scanner;

public class Pallindrome {
    public static void main(String[] args) {
        System.out.println("this is the program to find that it is pallindrom or not");
//        String str = "a,b,c,c,b,a";
        Scanner scan = new Scanner(System.in);
        String str = scan.nextLine();
        System.out.println(ispallindrome(str));
    }

    static boolean ispallindrome(String str){
        str.toLowerCase();
        if(str==null || str.length()==0){
            return true;
        }
        for(int i =0 ;i<=str.length()/2;i++){
            char start = str.charAt(i);
            char end = str.charAt(str.length()-1-i);
            if(start != end){
                return false;
            }
        }
        return true;
    }

}
