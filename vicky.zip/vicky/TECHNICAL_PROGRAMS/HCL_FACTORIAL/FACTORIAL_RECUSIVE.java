package com.vicky.TECHNICAL_PROGRAMS.HCL_FACTORIAL;

import java.util.Scanner;

public class FACTORIAL_RECUSIVE {
    public static void main(String[] args) {
        System.out.println("this is the program to print the factorial number");
        Scanner scan = new Scanner(System.in);
        int input = scan.nextInt();
        if(input<0){
            System.out.println("less than zero should not be an factorial");
        }
        System.out.println(factorial(input));
    }

    static int factorial(int input){
        if(input == 0 || input ==1){
            return 1;
        }
        return input*factorial(input-1);
    }
}
