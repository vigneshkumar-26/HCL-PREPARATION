package com.vicky.TECHNICAL_PROGRAMS.HCL_firstnonrepeated;

public class NON_REPEATEDFIRST {
    public static void main(String[] args) {
        System.out.println("this is the program to find FIRST NOT REPEATED ELEMENT");
        String input = "swiwiss";
        char result = nonrepeated(input);
        if(result!=0){
            System.out.println(result);
        }
        else{
            System.out.println("no repeated charaters");
        }
    }

    static char nonrepeated(String input){
        for(int i =0;i<input.length();i++){
            char ch = input.charAt(i);
            if(input.indexOf(ch)==input.lastIndexOf(ch)){
                return ch;
            }
        }
        return 0;
    }

}

