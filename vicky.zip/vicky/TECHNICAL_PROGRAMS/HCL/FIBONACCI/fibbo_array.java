package com.vicky.TECHNICAL_PROGRAMS.HCL.FIBONACCI;

public class fibbo_array {
    public static void main(String[] args) {
        System.out.println("this is program of fibbo in array");
        int n = 10;
        int [] arr = new int[n];
        arr[0] = 0;
        arr[1] = 1;
        for(int i =0;i<n;i++){
            System.out.print(arr[0] + " ");
            int next = arr[0]+arr[1];
            arr[0] = arr[1];
            arr[1] = next;
        }
    }
}
