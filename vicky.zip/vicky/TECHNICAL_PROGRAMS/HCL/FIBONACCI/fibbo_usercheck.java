package com.vicky.TECHNICAL_PROGRAMS.HCL.FIBONACCI;

import java.util.Scanner;

public class fibbo_usercheck {
    public static void main(String[] args) {
        System.out.println("this is the program of nth fibbi number");
        Scanner scan = new Scanner(System.in);
        System.out.println("enter the number");
        long n = scan.nextInt();
        long first = 0;
        long second = 1;
        long next =0;
        for(int i =0;i<n-1;i++){
//            System.out.println(first); use this if you want full length of fibbi
            next = first + second;
            first = second;
            second = next;
        }
        System.out.println(second);
    }
}
