package com.vicky.TECHNICAL_PROGRAMS.HCL_PRIME_NUMS;

import java.util.Scanner;

public class PRIME_NUMBER {
    public static void main(String[] args) {
        System.out.println("this is the prgram to find that is  the prime nubmer");
        Scanner scan = new Scanner(System.in);
        long number = scan.nextLong();
        boolean isprime = true;
        int c =2;
        while(c<number){
            if(number % c == 0){
                isprime = false;
                break;
            }
            c = c+1;
        }
        if(isprime == true){
            System.out.println("this is  the prime number");
        }
        else{
            System.out.println("this is not the prime numbrer");
        }
    }
}
