package com.vicky.TECHNICAL_PROGRAMS.HCL_ASCIIVAL;

public class printing_alphabets {
    public static void main(String[] args) {
        System.out.println("this is the program of printing all the alphabets by char");
        String series = "";
        for(int i =0;i<26;i++){
            char ch = (char)('a'+i);
            System.out.println(ch);
            series = series+ch;
        }
        System.out.println(series);
    }
}
