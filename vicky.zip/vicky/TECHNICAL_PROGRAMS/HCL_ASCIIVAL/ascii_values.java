package com.vicky.TECHNICAL_PROGRAMS.HCL_ASCIIVAL;

public class ascii_values {
    public static void main(String[] args) {
        System.out.println("this is the program of ascii values");
        for(int i =0; i<129;i++){
            System.out.println(i+":"+(char)i);
        }
    }
}
