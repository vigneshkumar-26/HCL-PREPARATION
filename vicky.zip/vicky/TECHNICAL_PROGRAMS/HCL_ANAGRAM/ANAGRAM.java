package com.vicky.TECHNICAL_PROGRAMS.HCL_ANAGRAM;

import java.util.Arrays;
import java.util.Scanner;

public class ANAGRAM {
    public static void main(String[] args) {
        System.out.println("this is the program to find the inputs are anagram");
        Scanner scan = new Scanner(System.in);
        String input1 = scan.nextLine();
        String input2 = scan.nextLine();
        if (input1.length() != input2.length()) {
            System.out.println("this is not an anagram");
        }
        System.out.println(anagrams(input1, input2));
    }

    static boolean anagrams(String input1, String input2) {
        input1.toLowerCase();
        input2.toLowerCase();
        char[] ch1 = input1.toCharArray();
        char[] ch2 = input2.toCharArray();
        Arrays.sort(ch1);
        Arrays.sort(ch2);

        return Arrays.equals(ch1,ch2);
    }
}
