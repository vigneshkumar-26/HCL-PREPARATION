package com.vicky.TECHNICAL_PROGRAMS.HCL_REVERSE;

import java.util.Arrays;
import java.util.Scanner;

public class REVERSE_NUMBERS {
    public static void main(String[] args) {
        System.out.println("this is the program of reversing the number through scanner");
        Scanner scan = new Scanner(System.in);
        int nums = scan.nextInt();
        int reverse = 0;
        while(nums != 0){
            int digit = nums % 10;
            reverse = reverse*10 + digit;
            nums = nums / 10;
        }
        System.out.println(reverse);
    }
}


