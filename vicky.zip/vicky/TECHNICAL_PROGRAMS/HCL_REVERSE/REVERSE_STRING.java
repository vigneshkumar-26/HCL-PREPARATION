package com.vicky.TECHNICAL_PROGRAMS.HCL_REVERSE;

import java.util.Scanner;

public class REVERSE_STRING {
    public static void main(String[] args) {
        System.out.println("this is the program of reversing the string");
        Scanner scan = new Scanner(System.in);
        String str = scan.nextLine();
        String reverse = "";
        for(int i = str.length()-1;i>=0;i--){
            reverse = reverse + str.charAt(i);
        }
        System.out.println(reverse);
    }
}
