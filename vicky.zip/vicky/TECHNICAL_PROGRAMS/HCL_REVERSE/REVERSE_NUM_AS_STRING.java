package com.vicky.TECHNICAL_PROGRAMS.HCL_REVERSE;

import java.util.Scanner;

public class REVERSE_NUM_AS_STRING {
    public static void main(String[] args) {
        System.out.println("this is the program of printing the numbers as string in reversing");
        Scanner scan = new Scanner(System.in);
        String nums = scan.nextLine();
        String reverse ="";
        for(int i = nums.length()-1;i>=0;i--){
            reverse = reverse + nums.charAt(i);
        }
        System.out.println(reverse);
    }
}
