package com.vicky.TECHNICAL_PROGRAMS.HCL_REMOVE_DUPLICATE;

import java.util.Scanner;

public class remove_duplicate_numbers {
    public static void main(String[] args) {
        System.out.println("this is the program of removing the duplicate nubmers");
        Scanner scan = new Scanner(System.in);
        int input = scan.nextInt();
    }
}
