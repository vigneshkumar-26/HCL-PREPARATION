package com.vicky.TECHNICAL_PROGRAMS.HCL_REMOVE_DUPLICATE;

import java.util.Scanner;

public class remove_duplicate_string {
    public static void main(String[] args) {
        System.out.println("this is the program of remove duplicate string");
        Scanner scan = new Scanner(System.in);
        String input = scan.nextLine();
        String result = duplicate(input);
        System.out.println(result);
    }

    static String duplicate(String input){
        StringBuilder result = new StringBuilder();
        StringBuilder removed = new StringBuilder();
        boolean[] seen = new boolean[26];
        for(int i =0;i<input.length()-1;i++){
            char ch = input.charAt(i);
            if(!seen[ch - 'a']){
                seen[ch - 'a'] = true;
            }
            result.append(ch);
            removed.append(ch);
        }
        System.out.println(removed);
        return result.toString();
    }
}
